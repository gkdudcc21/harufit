// backend/src/services/calendarGoalService.js
// 이 파일은 calendarGoalController에서 더 복잡한 비즈니스 로직이 필요할 때 사용합니다.
// 현재는 빈 파일로 두거나, 필요한 경우 기능을 추가합니다.